
package com.test.innovate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.*;

public class LoginPageValidation{
	

	public static void validateCredentials(String ecode, String passwd)
	{
		
	String connString =
			"jdbc:sqlserver://in482021s.database.windows.net:1433;"
			+ "database=in482021;"
			+ "user=i5_admin@in482021s;"
			+ "password=teami5@2021;"
			+ "encrypt=true;"
			+ "trustServerCertificate=false;"
			+ "hostNameInCertificate=*.database.windows.net;"
			+ "loginTimeout=30;";
	
	String connectionUrl = "jdbc:sqlserver://in482021s.database.windows.net:1433;database=in482021;encrypt=true;trustServerCertificate=true;";
    String user = "i5_admin@in482021s";
    String pass = "teami5@2021";
	
	Connection connection=null;
	Statement statement = null;
	ResultSet resultSet = null;
	
	try
	{
		loginPage lp = new loginPage();
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		connection = DriverManager.getConnection(connectionUrl,user,pass);
		String userTblQuery = "Select * from user_auth where uid = ? and pwd =?";
		
		PreparedStatement inStmt = connection.prepareStatement(userTblQuery);
		
		inStmt.setString(1, ecode);
		inStmt.setString(2, passwd);
		
		
		
		resultSet = inStmt.executeQuery();
		
		if(resultSet.next())
		{
			System.out.println("Valid User");
		}
		else
		{
			System.out.println("Invalid User");
		}
	}
	
	catch (Exception e)
	{
		e.printStackTrace();
		
	}

	finally
	{
		System.out.println("Done !!!");
	}



}


}