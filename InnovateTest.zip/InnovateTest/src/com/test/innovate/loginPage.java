package com.test.innovate;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLData;
import java.util.Scanner;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.SQLServerDriver;

@WebServlet("/loginPage")
public class loginPage extends HttpServlet {
	
	public String ecode,pass;
	

	Connection connection=null;
	Statement statement = null;
	ResultSet resultSet = null;
	
	/*public void init(ServletConfig config) throws ServletException
	{
		try
		{
			String connString =
					"jdbc:sqlserver://in482021s.database.windows.net:1433;"
					+ "database=in482021;"
					+ "user=i5_admin@in482021s;"
					+ "password=teami5@2021;"
					+ "encrypt=true;"
					+ "trustServerCertificate=false;"
					+ "hostNameInCertificate=*.database.windows.net;"
					+ "loginTimeout=30;";

			//loginPage lp = new loginPage();
	       			
			String connectionUrl = "jdbc:sqlserver://in482021s.database.windows.net:1433;database=in482021;encrypt=true;trustServerCertificate=true;";
		    String user = "i5_admin@in482021s";
		    String pass = "teami5@2021";
		    
		    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(connectionUrl,user,pass);
			


	    //    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	      //  Class.forName("com.)
			//connection = DriverManager.getConnection(connectionUrl,user,pass);
			//connection = DriverManager.getConnection(connString);

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
	
	}*/
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	
	{
		//String ecode,pass;
		
		//ecode="";
		//pass="";
		
		res.setContentType("text/html");
		
		
		ecode = req.getParameter("ecode");
		pass = req.getParameter("pass");
		
		System.out.println("\n Entered Ecode : " +ecode);
		System.out.println("\n Entered Pass  : " +pass);
	
		
		res.setContentType("text/html");
		
		PrintWriter out = res.getWriter();
		
		LoginPageValidation.validateCredentials(ecode,pass);
		
		/*String connString =
				"jdbc:sqlserver://in482021s.database.windows.net:1433;"
				+ "database=in482021;"
				+ "user=i5_admin@in482021s;"
				+ "password=teami5@2021;"
				+ "encrypt=true;"
				+ "trustServerCertificate=false;"
				+ "hostNameInCertificate=*.database.windows.net;"
				+ "loginTimeout=30;";
		
		Connection connection=null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try
		{	
			String connectionUrl = "jdbc:sqlserver://in482021s.database.windows.net:1433;database=in482021;encrypt=true;trustServerCertificate=true;";
		    String user = "i5_admin@in482021s";
		    String pass = "teami5@2021";
		    
		    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(connectionUrl,user,pass);
			//connection = DriverManager.getConnection(connString);
			String sqlstmt = "Select * from borrower_ldgr";
			String sqldel = "delete from borrower_ldgr where blid=1;";
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
			}
			
			statement.executeUpdate(sqldel);
			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
			}
			
			
			
			String sqlstmt = "Select * from lender_ldgr";
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getString(4));
			}
			
			String updStmt = "Update lender_ldgr Set amount = 50000 "
					+ "Where llid=1";
			statement.executeUpdate(updStmt);
			
			

			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next()) 
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getString(4));
			}
			
			
			
		}
		
		catch (Exception e)
		{
			e.printStackTrace();
			
		}

		finally
		{
			System.out.println("Done !!!");
		}

*/		
		//LoginPageValidation.validateCredentials();
		//SQLDatabaseTest.jeshur();
		
		/*String connectionUrl = "jdbc:sqlserver://in482021s.database.windows.net:1433;database=in482021;encrypt=true;trustServerCertificate=true;";
	    String user = "i5_admin@in482021s";
	    String pass = "teami5@2021";
		
		
		try
		{
			
			String connString =
					"jdbc:sqlserver://in482021s.database.windows.net:1433;"
					+ "database=in482021;"
					+ "user=i5_admin@in482021s;"
					+ "password=teami5@2021;"
					+ "encrypt=true;"
					+ "trustServerCertificate=false;"
					+ "hostNameInCertificate=*.database.windows.net;"
					+ "loginTimeout=30;";

			loginPage lp = new loginPage();
	        Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
			connection = DriverManager.getConnection(connectionUrl,user,pass);
			
			//connection = DriverManager.getConnection(connString);
			String userTblQuery = "Select * from user_auth where uid = ? and pwd =?";
			
			PreparedStatement inStmt = connection.prepareStatement(userTblQuery);
			
			inStmt.setString(1, ecode);
			inStmt.setString(2, pass);
			
			resultSet = inStmt.executeQuery();
			
			if(!resultSet.next())
			{
				System.out.println("Valid User");
			}
			else
			{
				System.out.println("Invalid User");
			}
		}
		
		catch (Exception e)
		{
			e.printStackTrace();
			
		}

		finally
		{
			System.out.println("Done !!!");
		}
*/		
		res.sendRedirect("WelcomePage.jsp");
		
		String htmlResp = "<html>";
		htmlResp += "<h2> Your employee is : " + ecode + "<br/>";
		htmlResp += "<h2> Welcome to the Lend a Friend !!! <br/>";
		htmlResp += "</html>";
		
		out.println(htmlResp);

	}
	
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		
			//String ecode,pass;
			
			//ecode="";
			//pass="";
			
			/*res.setContentType("text/html");
			
			PrintWriter out = res.getWriter();
			
			String htmlResp = "<html>";
			htmlResp += "<h2> Your employee is : " + ecode + "<br/>";
			htmlResp += "<h2> Welcome to the Lend a Friend !!! <br/>";
			htmlResp += "</html>";
			
			out.println(htmlResp);*/
			
		
		
	}

	
}
