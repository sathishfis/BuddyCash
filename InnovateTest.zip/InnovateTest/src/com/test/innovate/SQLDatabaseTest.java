package com.test.innovate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import com.microsoft.sqlserver.jdbc.*;

public class SQLDatabaseTest extends loginPage{

	//public static void main(String[] args) {
		public static void jeshur() {
			
		String connString =
				"jdbc:sqlserver://in482021s.database.windows.net:1433;"
				+ "database=in482021;"
				+ "user=i5_admin@in482021s;"
				+ "password=teami5@2021;"
				+ "encrypt=true;"
				+ "trustServerCertificate=false;"
				+ "hostNameInCertificate=*.database.windows.net;"
				+ "loginTimeout=30;";
		
		Connection connection=null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try
		{
			connection = DriverManager.getConnection(connString);
			/*String sqlstmt = "Select * from borrower_ldgr";
			String sqldel = "delete from borrower_ldgr where blid=1;";
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
			}
			
			statement.executeUpdate(sqldel);
			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
			}*/
			
			
			
			String sqlstmt = "Select * from lender_ldgr";
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next())
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getString(4));
			}
			
			String updStmt = "Update lender_ldgr Set amount = 50000 "
					+ "Where llid=1";
			statement.executeUpdate(updStmt);
			
			

			
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlstmt);
			
			while(resultSet.next()) 
			{
				System.out.println(resultSet.getString(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getString(3));
				System.out.println(resultSet.getString(4));
			}
			
			
			
		}
		
		catch (Exception e)
		{
			e.printStackTrace();
			
		}

		finally
		{
			System.out.println("Done !!!");
		}
		// TODO Auto-generated method stub

	}

}
